package main

import ("fmt"; "net/http"; "html/template")
/////СТРУКТУРА//( он же пользовательский тип данных/объект)//
type User struct {
  Name string
  Age uint16
  Money int16
  Avg_grades, Happieness float64
  Hobbies []string
//////СТРУКТУРА....//
}
/// обращаемся к объекту типа ЮЗЕР и печатаем атрибуты объекта ЮЗЕР
func (u *User) getAllInfo() string  {
  return fmt.Sprintf("User name is %s. He is %d and he " +
    " has money equal: %d", u.Name, u.Age, u.Money)
}
/////
func (u *User) setNewName(newName string) {
  u.Name = newName
}

func home_page(w http.ResponseWriter, r *http.Request) {
  bob := User{"Bob", 25, -50, 4.2, 0.8, []string{"Football", "hobbie 2", "bike", "coocing"}}

  tmpl, _ :=template.ParseFiles("templates/homepage.html")
  tmpl.Execute(w, bob )
// fmt.Fprintf(w, `<h1>Main text!!</h1> <b> Main Texts</b>`)
     }

 func contacts_page(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "Go contacts contacts  is super easy")
}
func contacts(w http.ResponseWriter, r *http.Request) {
   fmt.Fprintf(w, "!!!Contacts!!!")
}
func hadleRequest() {
http.HandleFunc("/", home_page)
http.HandleFunc("/cont/", contacts)
http.ListenAndServe(":8080", nil)
}
// func handleRequest() {
//   fmt.Println("GO RULZ ")
//  http.HandleFunc("/", home_page)
//  http.HandleFunc("/contacts", contacts_page)
//  http.ListenAndServe(":8080", nil)

func main()  {
  /// var bob user =  .....
//   bob := User{name: "bob", age: 25, money: -50, avg_grades: 4.2, happieness: 0.8}


  hadleRequest()


}
